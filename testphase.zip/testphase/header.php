<html>
    <head>
        <title>Idcheck Teck Test</title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css"> 
    </head>
    <body>
        <div class="warpper">
            <div class="bgOverlay">
                <!-----------APP HEADER---------->
                <div class="appHeader">
                    <a href="/">
                        <h2>Idcheck Teck Test</h2>
                    </a>
                </div>