<?php include 'header.php'; ?>

<div class="mainBody">
    <div class="entryForm">
        <h3>Add Entry</h3>
        <form id="myentryForm" method="post" action="">
            <!---------FOR TITLE----------->
            <div class="formGroup">
                <label for="dropdown_title">Dropdown</label>
                <select name="selectBox" id="selectBox">
                    <option value="">---</option>
                    <option value="Country">Country</option>
                    <option value="State">State</option>
                    <option value="City">City</option>
                    <option value="PropertyManager">PropertyManager</option>
                </select>
                <span id="selectBoxError"></span>
            </div>
            
            <!---------TenantID----------->
            <div class="formGroup">
                <label for="TenantID">TenantID</label>
                <input type="text" name="TenantID" id="TenantID">
                <span id="tenantError"></span>
            </div>
            
            <!---------Name----------->
            <div class="formGroup">
                <label for="entryName">Name</label>
                 <input type="text" name="entryName" id="entryName">
                <span id="entryNameError"></span>
            </div>
            
            <div class="actionGroup">
                <input type="reset" name="entry_reset" id="entry_reset" value="Reset">
                <input type="submit" name="entry_submit" id="entry_submit" value="Submit">
            </div>
            
            <div id="insertResult"></div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>