 <!--------- APP FOOTER ----------->
                <div class="appFooter">
                    <div class="container">
                        <p>&copy; <?php echo date('Y') ?> Muhammad Shoaib</p>
                    </div>
                </div>
                
            </div>
        </div>
        <script type="text/javascript" src="assets/js/jquery-3.1.0.min.js"></script>
        <script type="text/javascript" src="assets/js/custom.js"></script>
    </body>
</html>