jQuery(document).ready(function($){
    $("#selectBox").change(function(){
        if ($("#selectBox").val() === "") {
            $("#selectBoxError").text("please chose a option");
            
        }
        else{
            $("#selectBoxError").text("");
           
        }
    });
    
    /*Number Walidation VALIDATION START*/
    $("#TenantID").change(function(){
        var TenantID = $(this).val();
        if(TenantID.length == 0 || !/^[0-9]+$/.test(TenantID)){
            $("#tenantError").text("please add only number");
            $(this).css("background-color", "red");
            return false;
        }
        else{
            $("#tenantError").text("");
            $(this).css("background-color", "white");
        }
    });
    
    
    $("#entryName").change(function(){
        var entryName = $(this).val();
        if(/[^a-zA-Z ]/.test(entryName) || entryName.length < 3 || entryName.length > 100){
            $("#entryNameError").text("Must be at least 3 to 100 characters in length and should only consist of alphabets.");
            $(this).css("background-color", "red");
        }
        else{
            $("#entryNameError").text(" ");
            $(this).css("background-color", "white");
        }
    }); 
    
    
    
    
    $("#entry_submit").click(function(e){
        e.preventDefault();
        var selectBox = $("#selectBox").val();
        var TenantID = $("#TenantID").val();
        var entryName = $("#entryName").val();
        

        if(TenantID.length == 0 || !/^[0-9]+$/.test(TenantID)){
            $("#tenantError").text("please add only number");
            return false;
        }
        else{
            $("#tenantError").text("");
        }
        
        if(/[^a-zA-Z ]/.test(entryName) || entryName.length < 3 || entryName.length > 100){
            $("#entryNameError").text("Must be at least 3 to 100 characters in length and should only consist of alphabets.");
        }
        else{
            $("#entryNameError").text(" ");
        }
  
        
        $.ajax({
            url:"functions/entryfun.php",
            type:"POST",
            data:{slBox:selectBox,trId:TenantID,enName:entryName},
            success:function(data){
                $("#insertResult").text("you entry successfully submit");
                return false;
            }
        });
        
    });
    
    $("#entry_reset").click(function(e){
        e.preventDefault();
        $("#myentryForm").trigger("reset");
        $("#insertResult").html("");
    });
    
    
});