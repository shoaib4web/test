<?php include 'header.php'; ?>
<div class="mainBody">
    <!---------APP BUTTON LINK------>
    <article class="entryHome">
        <div class="addEntry">
            <a href="addentry.php">Add entry</a>
        </div>
        <div class="searchEntry">
            <a href="searchentry.php">Search entry</a>
        </div>
    </article>
</div>
<?php include 'footer.php'; ?>               