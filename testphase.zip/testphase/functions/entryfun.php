<?php
    include '../db/conection.php'; 

    echo "you entry successfully submit";
        
         
   
 