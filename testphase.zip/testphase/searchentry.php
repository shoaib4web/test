<?php include 'header.php'; ?>
<?php include './db/conection.php';  ?>
<div class="mainBody">
    <!----------SEARCH BOX---------->
    <div class="searchBox">
        <div class="container">
            <h2>Search A Entry</h2>
            <form method="get" enctype="multipart/form-data">
                <div class="serachForm">
                    <input type="search" id="search_entry" name="search_recipe">
                    <button type="submit" id="entrySerach">
                        <img src="images/search.png" alt="serach">
                    </button>
                </div>
            </form>
        </div>
    </div>
    
</div>
<?php include 'footer.php'; ?>